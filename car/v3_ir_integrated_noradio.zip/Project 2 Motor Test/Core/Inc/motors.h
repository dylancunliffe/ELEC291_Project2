#ifndef MOTORS_H
#define MOTORS_H



#ifdef __cplusplus
extern "C" {
#endif


#include <stdint.h>

void Motors_SetSpeed(int32_t left, int32_t right);

void Motors_Stop(void);

void TurnMTR(int8_t horz, int8_t vert, uint8_t eco_flag);

#ifdef __cplusplus
}
#endif

#endif
