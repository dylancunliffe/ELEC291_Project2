/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

typedef struct {
    uint8_t stop;
    uint8_t valid_config;
    uint8_t auto_mode;
    uint8_t tof_object;
    uint8_t intersection_detected;
    uint8_t signal_lost;
    uint8_t tof_init_success;
    uint8_t tof_busy;
    uint8_t eco_mode;
    uint8_t rotate_button;
    uint8_t address_temp;
} FSMFlags;


extern volatile FSMFlags flags;

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define IR_RX_Pin GPIO_PIN_14
#define IR_RX_GPIO_Port GPIOC
#define IR_RX_EXTI_IRQn EXTI4_15_IRQn
#define SPK_OUT_Pin GPIO_PIN_15
#define SPK_OUT_GPIO_Port GPIOC
#define INDUCTOR_ADC_1_Pin GPIO_PIN_0
#define INDUCTOR_ADC_1_GPIO_Port GPIOA
#define INDUCTOR_ADC_2_Pin GPIO_PIN_1
#define INDUCTOR_ADC_2_GPIO_Port GPIOA
#define INDUCTOR_ADC_3_Pin GPIO_PIN_2
#define INDUCTOR_ADC_3_GPIO_Port GPIOA
#define IR_TX_Pin GPIO_PIN_3
#define IR_TX_GPIO_Port GPIOA
#define RADIO_CSN_Pin GPIO_PIN_4
#define RADIO_CSN_GPIO_Port GPIOA
#define RADIO_SCK_Pin GPIO_PIN_5
#define RADIO_SCK_GPIO_Port GPIOA
#define RADIO_MISO_Pin GPIO_PIN_6
#define RADIO_MISO_GPIO_Port GPIOA
#define RADIO_MOSI_Pin GPIO_PIN_7
#define RADIO_MOSI_GPIO_Port GPIOA
#define RADIO_CE_Pin GPIO_PIN_0
#define RADIO_CE_GPIO_Port GPIOB
#define RADIO_IRQ_Pin GPIO_PIN_1
#define RADIO_IRQ_GPIO_Port GPIOB
#define RADIO_IRQ_EXTI_IRQn EXTI0_1_IRQn
#define LED_3_Pin GPIO_PIN_8
#define LED_3_GPIO_Port GPIOA
#define UART_TX_Pin GPIO_PIN_9
#define UART_TX_GPIO_Port GPIOA
#define UART_RX_Pin GPIO_PIN_10
#define UART_RX_GPIO_Port GPIOA
#define LED_L_Pin GPIO_PIN_11
#define LED_L_GPIO_Port GPIOA
#define LED_R_Pin GPIO_PIN_12
#define LED_R_GPIO_Port GPIOA
#define TOF_SCL_Pin GPIO_PIN_6
#define TOF_SCL_GPIO_Port GPIOB
#define TOF_SDA_Pin GPIO_PIN_7
#define TOF_SDA_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
