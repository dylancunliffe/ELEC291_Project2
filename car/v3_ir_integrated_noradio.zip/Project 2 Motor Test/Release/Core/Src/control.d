Core/Src/control.o: ../Core/Src/control.c ../Core/Inc/control.h \
 ../Core/Inc/sensors.h ../Core/Inc/motors.h
../Core/Inc/control.h:
../Core/Inc/sensors.h:
../Core/Inc/motors.h:
