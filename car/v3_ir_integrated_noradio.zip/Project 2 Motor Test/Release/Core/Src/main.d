Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal.h \
 ../Core/Inc/stm32l0xx_hal_conf.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l0xx.h \
 ../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l051xx.h \
 ../Drivers/CMSIS/Include/core_cm0plus.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32L0xx/Include/system_stm32l0xx.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_exti.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_dma.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_cortex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ramfunc.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_spi.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim_ex.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart.h \
 ../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart_ex.h \
 ../Core/Inc/tof.h ../Core/Inc/ir_r.h ../Core/Inc/motors.h \
 C:/Users/dylan/Documents/UBC/ELEC291/Project\ 2/STM\ Motor/Project\ 2\ Motor\ Test/Drivers/nrf24/NRF24.h \
 C:/Users/dylan/Documents/UBC/ELEC291/Project\ 2/STM\ Motor/Project\ 2\ Motor\ Test/Drivers/nrf24/NRF24_reg_addresses.h \
 ../Core/Inc/sensors.h ../Core/Inc/control.h ../Core/Inc/intersection.h \
 ../Core/Inc/speaker.h
../Core/Inc/main.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal.h:
../Core/Inc/stm32l0xx_hal_conf.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l0xx.h:
../Drivers/CMSIS/Device/ST/STM32L0xx/Include/stm32l051xx.h:
../Drivers/CMSIS/Include/core_cm0plus.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32L0xx/Include/system_stm32l0xx.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_rcc_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_exti.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_gpio_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_dma.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_cortex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_adc_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_flash_ramfunc.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_i2c_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_pwr_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_spi.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_tim_ex.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart.h:
../Drivers/STM32L0xx_HAL_Driver/Inc/stm32l0xx_hal_uart_ex.h:
../Core/Inc/tof.h:
../Core/Inc/ir_r.h:
../Core/Inc/motors.h:
C:/Users/dylan/Documents/UBC/ELEC291/Project\ 2/STM\ Motor/Project\ 2\ Motor\ Test/Drivers/nrf24/NRF24.h:
C:/Users/dylan/Documents/UBC/ELEC291/Project\ 2/STM\ Motor/Project\ 2\ Motor\ Test/Drivers/nrf24/NRF24_reg_addresses.h:
../Core/Inc/sensors.h:
../Core/Inc/control.h:
../Core/Inc/intersection.h:
../Core/Inc/speaker.h:
